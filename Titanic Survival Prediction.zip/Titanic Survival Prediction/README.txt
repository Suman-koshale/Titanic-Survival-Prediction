Project: Titanic Survival Prediction
Name: Suman Koshale

Dataset:
https://www.kaggle.com/datasets/bhanupratapbiswas/titanic-survival-datasets

Feature Engineering:
- Title extraction from Name
- Family size creation
- Cabin presence indicator

Models Used:
- Logistic Regression
- Random Forest Classifier

Best Model:
Random Forest Classifier

Explainability:
Feature importance shows gender, class and title as key survival factors.

Inference:
Run the last notebook cell for prediction.
